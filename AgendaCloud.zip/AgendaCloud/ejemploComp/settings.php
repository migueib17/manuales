<?php

/* Google App Client Id */
define('CLIENT_ID', '728049378257-jlk0j3revcgdoi9cpk1f75aek1nekjhl.apps.googleusercontent.com');

/* Google App Client Secret */
define('CLIENT_SECRET', '46Jdywd3SkSyna5AnIvujktV');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'http://localhost/AgendaCloud/ejemploComp/home.php');

?>